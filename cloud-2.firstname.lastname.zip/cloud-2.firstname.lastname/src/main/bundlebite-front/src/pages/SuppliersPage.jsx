import React from "react";


const SuppliersPage = () => {
    return (
        <div>
          <h1>SuppliersPage</h1>
        </div>
    );
}

export default SuppliersPage;